<?php

include('db.php');
session_start();

if (isset($_POST['insert'])) {
    $id_login = $_SESSION['login'];
    $namaPer = $_POST['nama-perusahaan'];
    $desc = $_POST['desc'];
    $desc = $_POST['desc'];
    $alamat = $_POST['alamat'];
    $pj = $_POST['pj'];
    $noTel = $_POST['noTel'];
    $city = $_POST['city'];
    if ($namaPer != '' && $desc != '' && $alamat != '' && $pj != '' && $noTel != '' && $city != '') {
        $sql = "INSERT INTO perusahaan (id_login, nama_per, deskripsi, alamat_per, nama_pj, noHP, kota) VALUES ('$id_login','$namaPer','$desc','$alamat','$pj','$noTel','$city')";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Berhasil Tambah')</script>";
            echo "<script>document.location.href='../form.php'</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        $error = "Form Kosong";
    }
}
if (isset($error)) {
    echo "<script>confirm('$error')</script>";
    echo "<script>document.location.href='../form.php'</script>";
}
