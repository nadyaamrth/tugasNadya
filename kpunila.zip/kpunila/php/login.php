<?php
include('db.php');
session_start();

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    if ($username != '' && $password != '') {
        $sql = "SELECT * FROM login WHERE username='$username';";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        if (!empty($row)) {
            echo "<script>confirm('Logged In')</script>";
            $_SESSION['login'] = $row['id'];
            echo "<script>document.location.href='../perusahaan.php'</script>";
        } else {
            $error = "Username or Password incorrect";
        }
    } else {
        $error = "Form kosong";
    }
}

if (isset($error)) {
    echo "<script>confirm('$error')</script>";
    echo "<script>document.location.href='../form.php'</script>";
}
