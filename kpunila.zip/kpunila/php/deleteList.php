<?php
include('db.php');
$id = $_GET['id'];
$sql = "DELETE FROM perusahaan WHERE id_per='$id';";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}

echo "<script>document.location.href='../perusahaan.php'</script>";