<?php
include('db.php');

if (isset($_POST['regis'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $confirm = md5($_POST['confirm']);
    if ($username != '' && $email != '' && $password != '' && $confirm != '') {
        if ($password == $confirm) {
            $select = "SELECT * FROM login WHERE email='$email' OR username='$username'";
            $result = $conn->query($select);
            $row = $result->fetch_assoc();
            if (empty($row)) {
                $sql = "INSERT INTO login (username, email, password) VALUES ('$username', '$email', '$password')";
                if ($conn->query($sql) === TRUE) {
                    echo "<script>confirm('Berhasil')</script>";
                    echo "<script>document.location.href='../form.php'</script>";
                } else {
                    $error = "Gagal Register";
                }
            } else {
                $error = "Email or Username has been used";
            }
        } else {
            $error = "Password tidak sama dengan Confirm Password";
        }
    } else {
        $error = "Form Kosong";
    }
}

if (isset($error)) {
    echo "<script>confirm('$error')</script>";
    echo "<script>document.location.href='../form.php'</script>";
}