<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>Sisfo KP</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
    <title>Contact Us</title>
</head>

<body>
    <div id="testimonial" class="testimonial">
        <div class="container">
            <?php
            include('php/db.php');
            $id = $_GET['id'];
            $sql = "SELECT * FROM perusahaan WHERE id_per='$id'";
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
            ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="titlepage">
                        <h3>Contact</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <div id="testimonial_slider" class="carousel slide banner-bg" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img class="first-slide" src="images/testimonial-img.png">
                                <div class="container">
                                    <div class="carousel-caption relat">
                                        <h3><?php echo $row['nama_pj']; ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <div class="contact">
                        <h3>Contact Us</h3>
                        <form>
                            <div class="row">
                                <div class="col-sm-12">
                                    <ul style="font-size: 25px;">
                                        <li><?php echo $row['nama_per']; ?></li>
                                        <li><?php echo $row['alamat_per']; ?></li>
                                        <li><?php echo $row['noHP']; ?></li>
                                    </ul>
                                </div>
                                <div class="col-sm-12" style="padding-top: 15%;">
                                    <a class="send" href="index.html">Done</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>