<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>Sisfo KP</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
    <link rel="stylesheet" href="css/list.css">
</head>

<body>
    <div class="title sticky-top">
        <center>
            <h2>List Perusahaan</h2>
        </center>
    </div>
    <div class="list">
        <div class="list-pt">
            <div class="detail">
                <div class="desc">
                    <?php
                    include('php/db.php');
                    session_start();
                    if (isset($_GET['src'])) {
                        $src = $_GET['src'];
                        $sql = "SELECT * FROM perusahaan WHERE kota='$src'";
                        // echo "<script>alert('src is defined')</script>";
                        echo "<h1>$src</h1>";
                    } else {
                        $sql = "SELECT * FROM perusahaan";
                        // echo "<script>alert('src is undefined')</script>";
                    }
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()) {
                    ?>
                        <div class="desc-control">
                            <img src="images/pt.png" class="pt-icon" alt="pt">
                            <div class="desc-text">
                                <p><?php echo $row['nama_per']; ?></p>
                                <p><?php echo $row['deskripsi']; ?></p>
                            </div>
                            <div class="action">
                                <button class="btn btn-primary" onclick="linked(<?php echo $row['id_per']; ?>)"><i class="fa fa-mobile-phone"></i></button>
                            </div>
                        </div>
                        <script>
                            function linked(id){
                                document.location.href="contact.php?id="+id;
                            }
                        </script>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>