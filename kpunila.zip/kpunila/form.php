<?php
session_start();
if (isset($_SESSION['login'])) {
  header('location:perusahaan.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- mobile metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="initial-scale=1, maximum-scale=1">
  <!-- site metas -->
  <title>Sisfo KP</title>
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="author" content="">
  <!-- bootstrap css -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- style css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- Responsive-->
  <link rel="stylesheet" href="css/responsive.css">
  <!-- fevicon -->
  <link rel="icon" href="images/fevicon.png" type="image/gif" />
  <!-- Scrollbar Custom CSS -->
  <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
  <!-- Tweaks for older IEs-->
  <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/form.css">
</head>

<body>
  <form action="php/login.php" style="max-width:500px;margin:auto" class="form1" method="POST">
    <center>
      <h2 style="color: white;">Login</h2>
    </center>
    <div class="input-container">
      <i class="fa fa-user icon"></i>
      <input class="input-field" type="text" placeholder="Username" name="username" autocomplete="off">
    </div>
    <div class="input-container">
      <i class="fa fa-key icon"></i>
      <input class="input-field" type="password" placeholder="Password" name="password" autocomplete="off">
    </div>
    <button type="submit" class="btn" name="login">Login</button><br><br>
    <a onclick="document.getElementById('id01').style.display='block'" style="width:auto" id="btn1">Register if you
      have company</a>
  </form class="form2">
  <div id="id01" class="modal">
    <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
    <form class="modal-content" action="php/regis.php" method="POST">
      <div class="container">
        <h1>Register</h1>
        <p>Please fill in this form to create an account.</p>
        <hr>
        <label for="username"><b>Username</b></label>
        <input type="text" placeholder="Enter Username" name="username" required class="inpt" autocomplete="off">

        <label for="email"><b>Email</b></label>
        <input type="text" placeholder="Enter Email" name="email" required class="inpt" autocomplete="off">

        <label for="psw"><b>Password</b></label>
        <input type="password" placeholder="Enter Password" name="password" required class="inpt">

        <label for="psw-repeat"><b>Confirm Password</b></label>
        <input type="password" placeholder="Repeat Password" name="confirm" required class="inpt">

        <div class="clearfix">
          <a type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</a>
          <button type="submit" class="signupbtn" id="btn1" name="regis">Register</button>
        </div>
      </div>
    </form>
  </div>

  <script>
    // Get the modal
    var modal = document.getElementById('id01');

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }
  </script>

</body>

</html>